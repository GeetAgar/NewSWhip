Language: Java
Version: 1.8
IDE: Eclipse

How to Run:

This is a normal java program, that will run and print the values on console
I recommend importing the Newswhip folder as a project in eclipse and running it using the taskbar or by righ clicking on the project -> Run As -> Java Program
You may need to add a jar opencsv-2.4 if it does not automatically gets added.


Contains of the Zip folder-

1. NewsWhip workspace
2. Readme.txt file
3. opencsv-2.4 jar file